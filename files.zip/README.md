# Zegswijzen over eten

Oefenprogramma voor laaggeletterde volwassenen die Nederlands leren (niveau A1).
Alles kan worden voorgelezen. Eén bestand, geen installatie nodig.

## Spelletjes
- Koppelen: foto, zegswijze en betekenis slepen
- Luisteren: zegswijze horen en de betekenis kiezen
- Memory: foto en zegswijze zoeken
- Juist of fout
- Nazeggen: de app beoordeelt de uitspraak

## Gebruiken
Open `index.html` in Chrome, Edge of Safari. Spraak en microfoon werken het best via `https://` (bv. GitHub Pages).

## Foto's en filmpjes toevoegen
Zet de bestanden in een map `media/` en vul in `index.html` bij elke zegswijze `img` of `vid` in:

```js
{e:'🍐', img:'media/peer.jpg', vid:'media/peer.mp4', n:'de peer', ...}
```

## Zegswijzen aanpassen
Bovenaan in het script staat de lijst `D`. Elke zegswijze heeft: `e` (emoji), `n` (naam), `z` (zegswijze), `m` (betekenis), `v` (voorbeeld).
